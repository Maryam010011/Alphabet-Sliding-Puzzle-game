public abstract class User0 {
    protected String username;

    public User0(String n) {
        username = n;
    }
    public abstract void display();
    public String getUsername() {
        return username;
    }
} 